G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,(5.1.9)-1*
G04 #@! TF.CreationDate,2021-08-06T09:52:32+02:00*
G04 #@! TF.ProjectId,Driver,44726976-6572-42e6-9b69-6361645f7063,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW (5.1.9)-1) date 2021-08-06 09:52:32*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
