#include "stm32g431xx.h"


void clockinit(void);
void init();
void opamp_init();
void adc_init();

void clockinit(void) {

	RCC->CR &= ~RCC_CR_HSION;
	FLASH->ACR |= FLASH_ACR_LATENCY_4WS | ( 1 << 10)| ( 1 << 9)| ( 1 << 8);
	PWR->CR5 &= ~PWR_CR5_R1MODE;



	RCC->CFGR &= ~RCC_CFGR_HPRE_3;		// reset sysclk prescaler to 1


	RCC->CR |= RCC_CR_HSEON;      // turn on HSE
	while (((RCC->CR)&RCC_CR_HSERDY)==0);          //wait til HSE is ready

	RCC->PLLCFGR &= ~0x00001000 ;
		RCC->PLLCFGR |= (0b11 << 0)
						| ( 0b0001 <<RCC_PLLCFGR_PLLM_Pos)
						| ( 85 << RCC_PLLCFGR_PLLN_Pos )
						| ( 0 << RCC_PLLCFGR_PLLR_Pos)
						| RCC_PLLCFGR_PLLREN
						| RCC_PLLCFGR_PLLPEN;

	RCC->CR |= RCC_CR_PLLON;
	while (((RCC->CR)&RCC_CR_PLLRDY)==0);        //wait til PLL is ready
		RCC->CFGR |= RCC_CFGR_SW_0 | RCC_CFGR_SW_1;

	SystemCoreClockUpdate();
	//RCC->CFGR |= (0b01<<RCC_CFGR_SW_Pos); // HSI16 selected as system clock

}

void init(){
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOBEN | RCC_AHB2ENR_GPIOCEN;

	GPIOA->MODER &= ~(0x3 << GPIO_MODER_MODE8_Pos);
	GPIOA->MODER &= ~(0x3 << GPIO_MODER_MODE9_Pos);
	GPIOA->MODER &= ~(0x3 << GPIO_MODER_MODE10_Pos);
	GPIOA->MODER &= ~(0x3 << GPIO_MODER_MODE12_Pos);

	GPIOA->MODER |= (0b10 << GPIO_MODER_MODE8_Pos)
					| (0b10 << GPIO_MODER_MODE9_Pos)
					| (0b10 << GPIO_MODER_MODE10_Pos)
					| (0b10 << GPIO_MODER_MODE12_Pos);

	GPIOA->OSPEEDR |= (0b10 << GPIO_OSPEEDR_OSPEED8_Pos)
					| (0b10 << GPIO_OSPEEDR_OSPEED9_Pos)
					| (0b10 << GPIO_OSPEEDR_OSPEED10_Pos)
					| (0b10 << GPIO_OSPEEDR_OSPEED12_Pos);

	GPIOA->OTYPER &= ~(1 << GPIO_OTYPER_OT8_Pos);
	GPIOA->OTYPER &= ~(1 << GPIO_OTYPER_OT9_Pos);
	GPIOA->OTYPER &= ~(1 << GPIO_OTYPER_OT10_Pos);
	GPIOA->OTYPER &= ~(1 << GPIO_OTYPER_OT12_Pos);

	GPIOA->PUPDR &= ~(0x3 << GPIO_PUPDR_PUPD8_Pos);
	GPIOA->PUPDR &= ~(0x3 << GPIO_PUPDR_PUPD9_Pos);
	GPIOA->PUPDR &= ~(0x3 << GPIO_PUPDR_PUPD10_Pos);
	GPIOA->PUPDR &= ~(0x3 << GPIO_PUPDR_PUPD12_Pos);


	GPIOA->AFR[1] |=  6 << GPIO_AFRH_AFSEL8_Pos
					| 6 << GPIO_AFRH_AFSEL9_Pos
					| 6 << GPIO_AFRH_AFSEL10_Pos
					| 6  << GPIO_AFRH_AFSEL12_Pos;

// GPIOB

	GPIOB->MODER &= ~(0x3 << GPIO_MODER_MODE15_Pos);

	GPIOB->MODER |= (0b10 << GPIO_MODER_MODE15_Pos);

	GPIOB->OSPEEDR |= (0b10 << GPIO_OSPEEDR_OSPEED15_Pos);

	GPIOB->OTYPER &= ~(1 << GPIO_OTYPER_OT15_Pos);

	GPIOB->PUPDR &= ~(0x3 << GPIO_PUPDR_PUPD15_Pos);

	GPIOB->AFR[1] |=  4 << GPIO_AFRH_AFSEL15_Pos;

	// GPIOC

	GPIOC->MODER &= ~(0x3 << GPIO_MODER_MODE13_Pos);

	GPIOC->MODER |= (0b10 << GPIO_MODER_MODE13_Pos);

	GPIOC->OSPEEDR |= (0b10 << GPIO_OSPEEDR_OSPEED13_Pos);

	GPIOC->OTYPER &= ~(1 << GPIO_OTYPER_OT13_Pos);

	GPIOC->PUPDR &= ~(0x3 << GPIO_PUPDR_PUPD13_Pos);

	GPIOC->AFR[1] |=  4 << GPIO_AFRH_AFSEL13_Pos;

	// Board LED for Debugging
/*
	GPIOC->MODER &= ~(0x3 << GPIO_MODER_MODE6_Pos);

	GPIOC->MODER |= (0b10 << GPIO_MODER_MODE6_Pos);

	GPIOC->OSPEEDR |= (0x1 << GPIO_OSPEEDR_OSPEED6_Pos);

	GPIOC->OTYPER &= ~(1 << GPIO_OTYPER_OT6_Pos);

	GPIOC->PUPDR |= (0b01 << GPIO_PUPDR_PUPD6_Pos);
*/
	// ADC OpAmps

	GPIOA->MODER &= ~(0x3 << GPIO_MODER_MODE2_Pos);
	GPIOA->MODER |= (0b11 << GPIO_MODER_MODE2_Pos);

	GPIOA->MODER &= ~(0x3 << GPIO_MODER_MODE6_Pos);
	GPIOA->MODER |= (0b11 << GPIO_MODER_MODE6_Pos);

	GPIOB->MODER &= ~(0x3 << GPIO_MODER_MODE1_Pos);
	GPIOB->MODER |= (0b11 << GPIO_MODER_MODE1_Pos);




}


void opamp_init(){
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;

	OPAMP1->CSR |= ( 0b00011 << OPAMP_CSR_PGGAIN_Pos) // Ganho x16, shunt de 3mOhm
				| OPAMP_CSR_OPAMPINTEN
				| OPAMP_CSR_VMSEL_1
				| OPAMP_CSR_OPAMPxEN;

	OPAMP2->CSR |= ( 0b00011 << OPAMP_CSR_PGGAIN_Pos)
					| OPAMP_CSR_OPAMPINTEN
					| OPAMP_CSR_VMSEL_1
					| OPAMP_CSR_OPAMPxEN;
/*
	OPAMP3->CSR |= ( 0b00011 << OPAMP_CSR_PGGAIN_Pos)
					| OPAMP_CSR_OPAMPINTEN
					| OPAMP_CSR_VMSEL_1
					| OPAMP_CSR_OPAMPxEN;
*/
// Acho que o terceiro não é necessário, mas tá aqui na mesma.

}

void adc_init(){
    RCC->AHB2ENR |= RCC_AHB2ENR_ADC12EN;



	RCC->CCIPR|= 0b01 << RCC_CCIPR_ADC12SEL_Pos;


    ADC1->CR &= ~ADC_CR_ADEN;
    ADC2->CR &= ~ADC_CR_ADEN;

    ADC1->CR &= ~ADC_CR_DEEPPWD;
    ADC2->CR &= ~ADC_CR_DEEPPWD;

    ADC1->CR |= ADC_CR_ADVREGEN;
    ADC2->CR |= ADC_CR_ADVREGEN;

    for(volatile int i = 0; i < 3000; i++); // isto é um delay de 20us, segundo o
    //datasheet é necessário

    ADC12_COMMON->CCR |= (0b0010 << ADC_CCR_PRESC_Pos);

    ADC1->CR |= ADC_CR_ADCAL;
    ADC2->CR |= ADC_CR_ADCAL;
       while ((ADC1->CR & ADC_CR_ADCAL ) || (ADC2->CR & ADC_CR_ADCAL ));


    ADC1->CFGR &= ~(ADC_CFGR_JQDIS);
    ADC1->CFGR |= (0b01 << ADC_CFGR_EXTEN_Pos)
				  |(9 << ADC_CFGR_EXTSEL_Pos); // External triggers for regular channels for ADC1
    // pag 618 do datasheet, isto é o que liga o tim1 ao adc

    ADC2->CFGR &= ~(ADC_CFGR_JQDIS);
    ADC2->CFGR |= (0b01 << ADC_CFGR_EXTEN_Pos)
				  |(9 << ADC_CFGR_EXTSEL_Pos);

    ADC12_COMMON->CCR |= ADC_CCR_VREFEN;


    ADC1->SQR1 |= (3 << ADC_SQR1_SQ1_Pos);
    ADC2->SQR1 |= (3 << ADC_SQR1_SQ1_Pos);

    ADC1->CR |= ADC_CR_ADEN;
    ADC2->CR |= ADC_CR_ADEN;
    while( ( (ADC1->ISR & ADC_ISR_ADRDY) && (ADC2->ISR & ADC_ISR_ADRDY) ) == 0 );

    ADC1->IER |= ADC_IER_EOCIE;

    NVIC_EnableIRQ(ADC1_2_IRQn);

    ADC1->CR |= ADC_CR_ADSTART;
    ADC2->CR |= ADC_CR_ADSTART;


}




